# Live Gazebo demo in GitHub Codespaces

This bundle starts the project's Gazebo Fortress simulation with ROS 2 Humble on Ubuntu 22.04 in a Codespace. It forwards the Gazebo desktop to your browser through noVNC. The cloud machine installs the dependencies. Your PC needs a browser and access to GitHub.

## Set up the Codespace

1. Unzip this bundle. Create a personal GitHub repository and choose **Private**. Under **Add file → Upload files**, upload the contents of the extracted **drone-gazebo-browser** folder. Make sure `.devcontainer/devcontainer.json` is at the repository root, alongside `ros/`. If your upload skips the dot-prefixed directory, add its two files from the archive with **Add file → Create new file** and enter the full paths `.devcontainer/devcontainer.json` and `.devcontainer/Dockerfile`.
2. On the repository page choose **Code → Codespaces → Create codespace on main**. If you have a choice of machines, a four-core Codespace gives software rendering more CPU time. The first build installs Gazebo and can take a few minutes.
3. Open the terminal in the Codespace and start a smoke run with the simulator's depth camera.

   ```bash
   bash ros/browser.sh 300 oracle
   ```

4. While the terminal waits, open the **Ports** panel and open the **6080** forwarded address in a new browser tab. Append `/vnc.html?autoconnect=true&resize=scale` to its base address. Keep the port **Private** and screen-share that browser tab for your demonstration.
5. Once the remote desktop appears, return to the Codespaces terminal and press **Enter** to launch Gazebo. When the flight ends, the terminal prints the outcome and waits so you can inspect the final scene. Press **Enter** there to close.

## Use MiDaS for the live demo

Run the same seed with the model after the smoke test. The first MiDaS run retrieves the project’s pinned weights from the official release on the cloud machine.

```bash
bash ros/browser.sh 300 midas
```

The launcher writes results and logs under `gazebo_runs/`. Use `oracle_300.json` or `midas_300.json` to check the run outcome. If no JSON appears, check the matching Gazebo, bridge and GUI logs. When you finish, stop the Codespace from your GitHub Codespaces dashboard.

The package, dev-container configuration and generated world files passed local checks. The first end-to-end Gazebo run on Codespaces is still pending. The earlier measured results came from the portable simulator.

- [GitHub Codespaces setup](https://docs.github.com/en/codespaces/developing-in-a-codespace/creating-a-codespace-for-a-repository?tool=vscode)
- [GitHub browser file uploads](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)
- [Codespaces port forwarding](https://docs.github.com/en/codespaces/developing-in-a-codespace/forwarding-ports-in-your-codespace?tool=vscode)
